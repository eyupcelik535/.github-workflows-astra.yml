# RedMagic Astra Codec Test

Bu Android uygulaması H.264/AVC ve H.265/HEVC video **kodlayıcılarının** Android MediaCodec API üzerinden 720p30, 720p60 ve 1080p60 destek bildirimlerini listeler. Ayrıca yalnızca uygun donanımsal kodlayıcılar için 720p60 MediaCodec başlatma denemesi yapar. Ekran görüntüsü almaz, ekran kaydetmez; sadece boş giriş yüzeyiyle kodlayıcıyı başlatır, dolayısıyla **gerçek 60 FPS hızını ölçmez**.

**Önemli:** Destek listesi, TikTok'un 60 FPS yayını açacağını kanıtlamaz. TikTok ek kontroller, yayın kısıtlamaları ve sunucu seçenekleri kullanabilir.

## GitHub Actions ile APK
1. GitHub'da boş bir depo oluşturun.
2. Bu ZIP içindeki `app`, `.github` klasörlerini ve kök dizindeki `build.gradle`, `settings.gradle`, `gradle.properties` dosyalarını deponun köküne yükleyin. (Gizli `.github` klasörünü de yükleyin.)
3. **Actions** -> **Astra Codec Test APK** -> **Run workflow** veya main dalına push yapın.
4. Çalışma bittikten sonra **Artifacts > Astra-Codec-Test-APK** dosyasını indirin. ZIP'in içindeki `app-debug.apk` uygulamadır.
5. Tablete kurup **KODLAYICILARI TEST ET** ardından **RAPORU PAYLAŞ** yapın.

## Rapor nasıl yorumlanır?
- `720p60 bildirimi: EVET`: MediaCodec API'sinin bu kodlayıcı için 720p60 desteği bildirdiği anlamına gelir.
- `720p60 kurulum: BAŞARILI`: MediaCodec encoder configure/start çağrısı çalıştı. **Gerçekte saniyede 60 kare üretimi test edilmedi.**
- `HAYIR`: Bu kodlayıcı 720p60'ı o API sorgusunda bildirmiyor; başka donanımsal kodlayıcıların sonucuna bakın.
- Sonuçlar EVET/BAŞARILI olsa bile TikTok farklı codec, 60 FPS profil, sunucu veya cihaz beyaz listesi kullanıyor olabilir.

## Mahremiyet
İnternet izni kullanılmaz. Sonuç raporunda yalnızca cihaz modeli, Android sürümü ve kodlayıcıların yetenekleri vardır; hesap/kimlik bilgileri yoktur.

## Yapılandırma
Android Gradle Plugin 8.9.2, Gradle 8.11.1, Java 17, compileSdk 35.
